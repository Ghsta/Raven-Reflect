package zen.relife.util;

public class TimerUtil {
    private long lastMS;

    private static long ms = getCurrentMS();
    private static long getCurrentMS() {
        return System.currentTimeMillis();
    }
    public static boolean hasReached(float milliseconds) {
        return getCurrentMS() - ms > milliseconds;
    }
    public boolean hasReached(final double milliseconds) {
        return this.getCurrentMS() - this.lastMS >= milliseconds;
    }

    public static void reset() {
        ms = getCurrentMS();
    }

    public boolean delay(final float milliSec) {
        return this.getTime() - this.lastMS >= milliSec;
    }

    public long getTime() {
        return System.nanoTime() / 1000000L;
    }
}
