package zen.relife.util.Packet;

import net.minecraft.client.Minecraft;

public class PlayerUtil {
    public static void tellPlayer(String message) {

    }
    public static void tellPlayerIrc(String message) {
    }
}
