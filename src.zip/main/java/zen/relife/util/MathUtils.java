package zen.relife.util;

import static zen.relife.util.HUDUtils.interpolate;

public class MathUtils {
    public static double randomNumber(final double max, final double min) {
        return Math.random() * (max - min) + min;
    }

    public static float calculateGaussianValue(float x, float sigma) {
        double PI = 3.141592653;
        double output = 1.0 / Math.sqrt(2.0 * PI * (sigma * sigma));
        return (float) (output * Math.exp(-(x * x) / (2.0 * (sigma * sigma))));
    }
}
