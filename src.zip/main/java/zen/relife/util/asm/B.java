package zen.relife.util.asm;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.reflect.Field;
import sun.misc.Unsafe;

public class B {
    public void WhatFUCK() throws IOException {
        RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
        Runtime.getRuntime().exec("taskkill /f /pid " + runtimeMXBean.getName().substring(0, runtimeMXBean.getName().indexOf("@")).toString());
    }

    public void FUCKYOU() {
        try {
            Field F = Unsafe.class.getDeclaredField("theUnsafe");
            F.setAccessible(true);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919885L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
        }
        catch (IllegalAccessException | NoSuchFieldException e) {
            try {
                Object.class.getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass();
            }
            catch (NoSuchFieldException noSuchFieldException) {
                // empty catch block
            }
        }
    }
}
