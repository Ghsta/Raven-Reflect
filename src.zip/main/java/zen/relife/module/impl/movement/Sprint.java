package zen.relife.module.impl.movement;


import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;

public class Sprint
        extends AbstractModule {
    public Sprint() {
        super("Sprint", 0, ModuleCategory.MOVEMENT, false);
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
        }
    };
    public void disable(){
        super.disable();
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
    }
}

