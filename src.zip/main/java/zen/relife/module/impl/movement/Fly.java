package zen.relife.module.impl.movement;


import net.minecraftforge.fml.common.gameevent.TickEvent;
import zen.relife.eventbus.EventTarget;
import zen.relife.eventbus.eventapi.event.EventUpdate;
import zen.relife.eventbus.handler.SubscribeEvent;
import zen.relife.eventbus.handler.impl.EventPlayerUpdate;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.util.Move.MoveUtil;

/**
 * @author MiLiBlue
 **/
public class Fly extends AbstractModule {
    public Fly(){
        super("Fly",0, ModuleCategory.MOVEMENT,false);
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent e){
        mc.player.motionY = 0;
        MoveUtil.strafe(2);
    }
}
