package zen.relife.module.impl.movement;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.setting.IntegerSetting;

public class FastLadder extends AbstractModule {
	IntegerSetting Speed = new IntegerSetting("Speed", 0.3, 0.0,  0.8, 1);
	public FastLadder() {
		super("FastLadder", 0, ModuleCategory.MOVEMENT,false);
		this.getSetting().add(this.Speed);
	}@SubscribeEvent
    public void onUpdate(TickEvent.ClientTickEvent e){
    	if(mc.world == null) return;
		if(!mc.player.isOnLadder() || mc.player.moveForward == 0 && mc.player.moveStrafing == 0) return;
		mc.player.motionY = Speed.getCurrent();
    }
}
