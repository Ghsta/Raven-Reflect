package zen.relife.module.impl.movement;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.setting.IntegerSetting;
import zen.relife.util.Relife1;
import zen.relife.util.TimerUtils;
import zen.relife.util.Tools;

public class HighJump
extends AbstractModule {
    TimerUtils timer = new TimerUtils();
    IntegerSetting horizontalValue = new IntegerSetting("Horizontal", 0.0, 0.0, 10.0, 1);
    IntegerSetting verticalValue = new IntegerSetting("Vertical", 5.0, 0.0, 10.0, 1);

    public HighJump() {
        super("HighJump", 0, ModuleCategory.MOVEMENT, false);
        this.getSetting().add(this.horizontalValue);
        this.getSetting().add(this.verticalValue);
    }

    @Override
    public void enable() {
        Tools.nullCheck();
        this.Jump();
        this.toggle();
        super.enable();
    }

    public void sendPacket(Packet packet) {
        Relife1.INSTANCE.sendPacket(packet);
    }

    public void Jump() {
        double yaw = Math.toRadians(HighJump.mc.player.rotationYaw);
        double x = -Math.sin(yaw) * this.horizontalValue.getCurrent();
        double z = Math.cos(yaw) * this.horizontalValue.getCurrent();
        this.sendPacket(new CPacketPlayer.Position(HighJump.mc.player.posX, HighJump.mc.player.posY, HighJump.mc.player.posZ, true));
        this.sendPacket(new CPacketPlayer.Position(0.5, 0.0, 0.5, true));
        this.sendPacket(new CPacketPlayer.Position(HighJump.mc.player.posX, HighJump.mc.player.posY, HighJump.mc.player.posZ, true));
        this.sendPacket(new CPacketPlayer.Position(HighJump.mc.player.posX + x, HighJump.mc.player.posY + this.verticalValue.getCurrent(), HighJump.mc.player.posZ + z, true));
        this.sendPacket(new CPacketPlayer.Position(0.5, 0.0, 0.5, true));
        this.sendPacket(new CPacketPlayer.Position(HighJump.mc.player.posX + 0.5, HighJump.mc.player.posY, HighJump.mc.player.posZ + 0.5, true));
        HighJump.mc.player.setPosition(HighJump.mc.player.posX + -Math.sin(yaw) * 0.04, HighJump.mc.player.posY, HighJump.mc.player.posZ + Math.cos(yaw) * 0.04);
    }
}

