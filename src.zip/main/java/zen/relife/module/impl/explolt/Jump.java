package zen.relife.module.impl.explolt;


import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import scala.tools.nsc.transform.SpecializeTypes;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;

public class Jump extends AbstractModule {

    public Jump() {
        super("Jump", Keyboard.KEY_NONE, ModuleCategory.EXPLOIT,false);
    }

    @SubscribeEvent
    public void TickEvent(TickEvent.PlayerTickEvent e) {
        if (!mc.isGamePaused()) {
            if (mc.player.onGround && Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode())) {
                mc.player.jump();
            }
        }
    }
}
