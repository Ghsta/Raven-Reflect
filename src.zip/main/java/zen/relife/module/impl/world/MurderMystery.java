package zen.relife.module.impl.world;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemSword;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.module.impl.combat.AntiBot;
import zen.relife.setting.EnableSetting;
import zen.relife.utils.Helper;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MurderMystery extends AbstractModule {

    public static boolean a1;
    public static int a2;
    private static List<EntityPlayer> m;
    private static List<EntityPlayer> bw;

    private EnableSetting Murder = new EnableSetting("Tell Everyone Murder", false);
    private EnableSetting Bow= new EnableSetting("Tell Everyone Bow", false);

    public MurderMystery() {
        super("MurderMystery", Keyboard.KEY_NONE, ModuleCategory.WORLD,false);
        this.getSetting().add(Murder);
        this.getSetting().add(Bow);

    }


    @Override
    public void disable() {
        MurderMystery.a1 = false;
        MurderMystery.a2 = 0;
    }

    @SubscribeEvent
    public void o(final RenderWorldLastEvent ev) {
        if (MurderMystery.mc.player.getWorldScoreboard() != null && MurderMystery.mc.player.getWorldScoreboard().getObjectiveInDisplaySlot(1) != null) {
            final String d = MurderMystery.mc.player.getWorldScoreboard().getObjectiveInDisplaySlot(1).getDisplayName();
            if (d.contains("MURDER") || d.contains("MYSTERY")) {
                for (final EntityPlayer en : MurderMystery.mc.world.playerEntities) {
                    if (en != MurderMystery.mc.player && !en.isInvisible()) {
                        if (en.getHeldItemMainhand() != null && en.getHeldItemMainhand().hasDisplayName()) {
                            final Item i = en.getHeldItemMainhand().getItem();
                            if (i instanceof ItemSword || i instanceof ItemAxe || en.getHeldItemMainhand().getDisplayName().replaceAll("§", "").equals("aKnife")) {
                                if (!MurderMystery.m.contains(en)) {
                                    MurderMystery.m.add(en);
                                    Helper.sendMessage(en.getName() + " is the murderer!");
                                    if(this.Murder.getEnable()){
                                        mc.player.sendChatMessage(en.getName() + " is the murderer!");
                                    }
                                }
                            }
                            else if (i instanceof ItemBow && !MurderMystery.bw.contains(en)) {
                                MurderMystery.bw.add(en);
                                Helper.sendMessage("[WARNING]"+en.getName()+" have bow! he maybe will kill you.");
                                if(this.Bow.getEnable()){
                                    mc.player.sendChatMessage(en.getName() + " have bow.");
                                }
                            }
                        }
                        int rgb = Color.green.getRGB();
                        if ((MurderMystery.m.contains(en) && !MurderMystery.bw.contains(en)) || (MurderMystery.m.contains(en) && MurderMystery.bw.contains(en))) {
                            rgb = Color.red.getRGB();
                        }
                        if (!MurderMystery.m.contains(en) && MurderMystery.bw.contains(en)) {
                            rgb = Color.orange.getRGB();
                        }
                    }
                }
            }
            else {
                this.c();
            }
        }
        else {
            this.c();
        }
    }

    private void c() {
        if (MurderMystery.m.size() > 0) {
            MurderMystery.m.clear();
        }
        if (MurderMystery.bw.size() > 0) {
            MurderMystery.bw.clear();
        }
    }

    static {
        MurderMystery.a1 = false;
        MurderMystery.a2 = 0;
        MurderMystery.m = new ArrayList<EntityPlayer>();
        MurderMystery.bw = new ArrayList<EntityPlayer>();
    }



}
