package zen.relife.module.impl.world;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSoup;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.setting.EnableSetting;
import zen.relife.setting.IntegerSetting;
import zen.relife.util.Relife1;

public class AutoSoup
extends AbstractModule {
    IntegerSetting health = new IntegerSetting("Health", 6.5, 0.5, 9.5, 1);
    IntegerSetting delay = new IntegerSetting("Delay", 350.0, 50.0, 1000.0, 0);
    EnableSetting drop = new EnableSetting("Drop", false);
    private int oldSlot = -1;

    public AutoSoup() {
        super("AutoSoup", 0, ModuleCategory.WORLD, false);
        this.getSetting().add(this.health);
        this.getSetting().add(this.delay);
        this.getSetting().add(this.drop);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        int soupSlot = AutoSoup.getSoupFromInventory();
        if (soupSlot != -1 && (double)AutoSoup.mc.player.getHealth() < this.health.getCurrent()) {
            Relife1.INSTANCE.sendPacket(new CPacketHeldItemChange(6));
            Relife1.INSTANCE.sendPacket(new CPacketPlayerTryUseItemOnBlock());
            Relife1.INSTANCE.sendPacket(new CPacketHeldItemChange(AutoSoup.mc.player.inventory.currentItem));
        }
    }

    private int findSoup(int startSlot, int endSlot) {
        for (int i = startSlot; i < endSlot; ++i) {
            ItemStack stack = AutoSoup.mc.player.inventory.getStackInSlot(i);
            if (stack == null || !(stack.getItem() instanceof ItemSoup)) continue;
            return i;
        }
        return -1;
    }

    private boolean shouldEatSoup() {
        return !((double)AutoSoup.mc.player.getHealth() > this.health.getCurrent() * 2.0);
    }

    private void stopIfEating() {
        if (this.oldSlot == -1) {
            return;
        }
        KeyBinding.setKeyBindState(AutoSoup.mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        AutoSoup.mc.player.inventory.currentItem = this.oldSlot;
        this.oldSlot = -1;
    }

    public static int getSoupFromInventory() {
        Minecraft mc = Minecraft.getMinecraft();
        int soup = -1;
        int counter = 0;
        for (int i = 1; i < 45; ++i) {
            ItemStack is;
            Item item;
            if (!mc.player.inventoryContainer.getSlot(i).getHasStack() || Item.getIdFromItem(item = (is = mc.player.inventoryContainer.getSlot(i).getStack()).getItem()) != 282) continue;
            ++counter;
            soup = i;
        }
        return soup;
    }
}

