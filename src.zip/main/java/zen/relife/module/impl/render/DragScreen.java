package zen.relife.module.impl.render;

import org.lwjgl.input.Keyboard;
import zen.relife.hud.HUDConfigScreen;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;

public class DragScreen extends AbstractModule {
    public DragScreen() {
        super("DragScreen", Keyboard.KEY_LMENU, ModuleCategory.RENDER, false);
    }

    @Override
    public void enable() {
        this.setState(false);
        mc.player.closeScreen();
        mc.displayGuiScreen(new HUDConfigScreen());
    }
}
