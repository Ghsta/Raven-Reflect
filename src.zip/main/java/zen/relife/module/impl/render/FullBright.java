package zen.relife.module.impl.render;


import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.util.Tools;

public class FullBright extends AbstractModule {
    private float old;

    public FullBright() {
        super("FullBright", 0, ModuleCategory.RENDER, false);
    }

    @Override
    public void enable() {
        this.old = FullBright.mc.gameSettings.gammaSetting;
        super.enable();
    }

    @Override
    public void disable() {
        super.enable();
        FullBright.mc.gameSettings.gammaSetting = this.old;
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (!Tools.isPlayerInGame()) {
            this.disable();
            return;
        }
        if (FullBright.mc.gameSettings.gammaSetting != 10000.0f) {
            FullBright.mc.gameSettings.gammaSetting = 10000.0f;
        }
    }
}

