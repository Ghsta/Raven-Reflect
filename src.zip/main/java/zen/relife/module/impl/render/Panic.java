package zen.relife.module.impl.render;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import zen.relife.Relife;
import zen.relife.manager.impl.ModuleManager;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;

public class Panic extends AbstractModule {
    public static boolean isPanic = false;

    public Panic() {
        super("Panic", Keyboard.KEY_INSERT, ModuleCategory.RENDER,true);
    }

    @Override
    public void enable() {
        isPanic = true;

        for (AbstractModule m : ModuleManager.modules) {
            if (m != this) {
                m.setToggled(false);
            }
        }
    }

    @Override
    public void disable() {
        isPanic = false;
    }
}
