package zen.relife.module.impl.configs;


import zen.relife.Config.*;
import zen.relife.Relife;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;

public class LoadConfig extends AbstractModule {
    public LoadConfig() {
        super("LoadConfig", 0, ModuleCategory.CONFIG, false);
    }

    @Override
    public void enable() {
        super.enable();
        this.toggle();
        try {
            IntegerConfig.loadState();
            EnableConfig.loadState();
            ModeConfig.loadState();
            KeyBindConfig.loadKey();
            ModuleConfig.loadModules();
            ClickGuiConfig.loadClickGui();
            for (AbstractModule m : Relife.INSTANCE.getModuleManager().getModules()) {
                m.isSilder(null);
                m.setMode(null);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

