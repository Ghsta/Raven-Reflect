package zen.relife.module.impl.configs;

import zen.relife.Config.*;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.util.Tools;

import java.io.File;

public class SaveConfig extends AbstractModule {
    private boolean kp;

    public SaveConfig() {
        super("SaveConfig", 0, ModuleCategory.CONFIG, false);
    }

    @Override
    public void enable() {
        super.enable();
        this.kp = true;
        this.toggle();
        try {
            File ConfigDir = new File(Tools.getConfigPath());
            if (!ConfigDir.exists()) {
                ConfigDir.mkdir();
            }
            EnableConfig.saveState();
            IntegerConfig.saveState();
            KeyBindConfig.saveKey();
            ModeConfig.saveState();
            ModuleConfig.saveModules();
            ClickGuiConfig.saveClickGui();
        }
        catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
        }
    }
}

