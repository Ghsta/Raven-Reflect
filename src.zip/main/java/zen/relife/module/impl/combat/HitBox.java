package zen.relife.module.impl.combat;


import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.setting.IntegerSetting;


public class HitBox extends AbstractModule {
    private IntegerSetting Size = new IntegerSetting("Size", 1, 0, 4, 1);

    public HitBox() {
        super("HitBox", Keyboard.KEY_NONE, ModuleCategory.COMBAT, false);
        this.getSetting().add(Size);

    }@SubscribeEvent
    public void enable(RenderWorldLastEvent e) {
        if (HitBox.mc.isSnooperEnabled()) {
            float size = (float) Size.getCurrent();

            for (EntityPlayer player : mc.world.playerEntities) {
                if (player != null && player != mc.player) {
                    player.setEntityBoundingBox(new AxisAlignedBB(
                            player.posX - size,
                            player.getEntityBoundingBox().minY,
                            player.posZ - size,
                            player.posX + size,
                            player.getEntityBoundingBox().maxY,
                            player.posZ + size
                    ));
                }
            }
        } else {
            for (EntityPlayer player : mc.world.playerEntities) {
                if (player != null && player != mc.player) {
                    player.setEntityBoundingBox(new AxisAlignedBB(
                            player.posX - 0.3F,
                            player.getEntityBoundingBox().minY,
                            player.posZ - 0.3F,
                            player.posX + 0.3F,
                            player.getEntityBoundingBox().maxY,
                            player.posZ + 0.3F
                    ));
                }
            }
        }
    }

    @Override
    public void disable() {}
}
