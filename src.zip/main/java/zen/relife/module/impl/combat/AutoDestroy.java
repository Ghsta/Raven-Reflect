package zen.relife.module.impl.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.setting.EnableSetting;
import zen.relife.setting.IntegerSetting;
import zen.relife.util.TimerUtil;

public class AutoDestroy extends AbstractModule {
    public static boolean destroy = false;
    private int oldcurrentitem;
    private IntegerSetting Delay = new IntegerSetting("Delay", 600, 0, 900, 1);
    private EnableSetting SwapBack= new EnableSetting("SwapBack", false);
    public AutoDestroy() {
        super("AutoShieldDestroy", Keyboard.KEY_NONE, ModuleCategory.COMBAT,false);
        this.getSetting().add(Delay);
        this.getSetting().add(SwapBack);
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent e) {
        double delay = Delay.getCurrent();
        boolean swapback = SwapBack.getEnable();

        for (EntityPlayer playerEntity : mc.world.playerEntities) {
            if (playerEntity != null && playerEntity != mc.player) {
                if (playerEntity.getHeldItemOffhand().getItem() instanceof ItemShield || playerEntity.getHeldItemMainhand().getItem() instanceof ItemShield) {
                    if (playerEntity.isHandActive()) {
                        if (findAxeInHotbar(mc) < 9 && findAxeInHotbar(mc) > 0) {
                            oldcurrentitem = mc.player.inventory.currentItem;
                            mc.player.inventory.currentItem = findAxeInHotbar(mc);
                            if (playerEntity.getHeldItemOffhand().getItem() instanceof ItemAxe) {
                                if (TimerUtil.hasReached((float) delay)) {
                                    mc.playerController.attackEntity(mc.player, playerEntity);
                                    TimerUtil.reset();
                                }
                            }
                        }
                        destroy = true;
                    } else {
                        destroy = false;
                        if (swapback) {
                            mc.player.inventory.currentItem = oldcurrentitem;
                        }
                    }
                } else {
                    destroy = false;
                }
            }
        }
    }

    private boolean isItemStackAxe(final ItemStack itemStack) {
        return itemStack.getItem() instanceof ItemAxe;
    }

    private int findAxeInHotbar(final Minecraft mc) {
        for (int index = 0; InventoryPlayer.isHotbar(index); index++) {
            if (isItemStackAxe(mc.player.inventory.getStackInSlot(index))) return index;
        }
        return -1;
    }

    @Override
    public void disable() {
        destroy = false;
    }
}
