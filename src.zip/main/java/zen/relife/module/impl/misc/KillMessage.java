package zen.relife.module.impl.misc;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.eventbus.EventTarget;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.module.impl.combat.KillAura;
import zen.relife.util.TimerUtil;

import java.util.Random;

public class KillMessage extends AbstractModule {
    public KillMessage() {
        super("KillMessage", Keyboard.KEY_NONE, ModuleCategory.MISC,false);
    }
    @EventTarget
    public void onUpdate(TickEvent.PlayerTickEvent e) {
        if ((KillAura.target.getHealth() <= 0.0f || KillAura.target.isDead) && KillAura.target instanceof EntityPlayer) {
            String[] messages = new String[]{"@[Relife]:你被我杀了"};
            String finalText = messages[new Random().nextInt(messages.length)];
            if (TimerUtil.hasReached(200)) {
                mc.player.sendChatMessage(KillAura.target.getName() + "," + " " + finalText);
                TimerUtil.reset();

            }
        }
    }
}
