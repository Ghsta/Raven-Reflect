package zen.relife.module.impl.misc;


import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;

public class AutoRespawn extends AbstractModule {
    public AutoRespawn() {
        super("AutoRespawn", Keyboard.KEY_NONE, ModuleCategory.MISC,false);}

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent e) {
        if (mc.player.isDead){
            mc.player.respawnPlayer();
        }
    }
}
