package zen.relife.hud.mod.impl;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import zen.relife.eventbus.handler.SubscribeEvent;
import zen.relife.hud.mod.HudMod;
import zen.relife.manager.impl.FontManager;
import zen.relife.module.impl.render.ClickGui;
import zen.relife.module.impl.render.Hud;
import zen.relife.setting.EnableSetting;
import zen.relife.ui.ClickGUI.CategorysPanels;
import zen.relife.ui.ClickGUI.ClickGUI;

public class Keystrokes extends HudMod {
    private static final int[] COLORS = new int[]{0xFFFFFF, 0xFF0000, 65280, 255, 0xFFFF00, 0xAA00AA};
    EnableSetting option = Hud.Keystrokes;

    public Keystrokes() {
        super("Keystrokes", 400, 5);
        this.movementKeys = new Key[5];
        this.mouseButtons = new MouseButton[2];
        this.newSpaces = new NewSpace[1];
        this.movementKeys[0] = new Key(Keystrokes.mc.gameSettings.keyBindForward, 26, 2);
        this.movementKeys[1] = new Key(Keystrokes.mc.gameSettings.keyBindBack, 26, 26);
        this.movementKeys[2] = new Key(Keystrokes.mc.gameSettings.keyBindLeft, 2, 26);
        this.movementKeys[3] = new Key(Keystrokes.mc.gameSettings.keyBindRight, 50, 26);
        this.movementKeys[4] = new Key(Keystrokes.mc.gameSettings.keyBindJump, 2, 74);
        this.mouseButtons[0] = new MouseButton(0, 2, 50);
        this.mouseButtons[1] = new MouseButton(1, 38, 50);
        this.newSpaces[0] = new NewSpace(Keystrokes.mc.gameSettings.keyBindJump, 2, 74);
    }



    @Override
    public void draw() {
        int x = 15;
        int y = 300;
        int textColor = this.getColor(0);
        this.drawMovementKeys(x, y, textColor);
        this.drawMouseButtons(x, y, textColor);
        this.drawNewSpace(x, y, textColor);
        int moduleWidth;
        int x1 = 0;
        int y1 = 0;
        int y2 = 0;
        int width = new ScaledResolution(mc).getScaledWidth();
        if(Hud.InventoryHUD.getEnable())
 {
            for (CategorysPanels categorysPanels : ClickGUI.categorysPanels) {
                if (!categorysPanels.category.name().equalsIgnoreCase("Keystrokes")) continue;
                y2 = categorysPanels.getY();
                if (categorysPanels.getX() > width / 2) {

                    y1 = categorysPanels.getY() + y + 18;
                    continue;
                }
                x1 = categorysPanels.getX();
                y1 = categorysPanels.getY() + y + 18;
                if (categorysPanels.getX() > width / 2) {
                    y1 = categorysPanels.getY() + y + 18;
                    continue;
                }
                x1 = categorysPanels.getX();
                y1 = categorysPanels.getY() + y + 18;
            }
        }
        if (!(Hud.mc.currentScreen instanceof ClickGUI)) {
            y1 -= 20;
        }
        super.draw();
    };
    @SubscribeEvent
    public void renderDummy(int mouseX, int mouseY) {
        int x = 15;
        int y = 300;
        int textColor = this.getColor(0);
        this.drawMovementKeys(x, y, textColor);
        this.drawMouseButtons(x, y, textColor);
        this.drawNewSpace(x, y, textColor);
        int moduleWidth;
        int x1 = 0;
        int y1 = 0;
        int y2 = 0;
        int width = new ScaledResolution(mc).getScaledWidth();
        if (option.getEnable())
        if(Hud.InventoryHUD.getEnable())
 {
                for (CategorysPanels categorysPanels : ClickGUI.categorysPanels) {
                    if (!categorysPanels.category.name().equalsIgnoreCase("Keystrokes")) continue;
                    y2 = categorysPanels.getY();
                    if (categorysPanels.getX() > width / 2) {

                        y1 = categorysPanels.getY() + y + 18;
                        continue;
                    }
                    y1 = categorysPanels.getY() + y + 18;
                    if (categorysPanels.getX() > width / 2) {
                        y1 = categorysPanels.getY() + y + 18;
                        continue;
                    }
                    x1 = categorysPanels.getX();
                    y1 = categorysPanels.getY() + y + 18;
                }
            }
        if (!(Hud.mc.currentScreen instanceof ClickGUI)) {
            y1 -= 20;
        }
        super.renderDummy(mouseX, mouseY);
    };


    private int getColor(int index) {
        if (index == 6) {
            return Color.HSBtoRGB((float)(System.currentTimeMillis() % 1000L) / 1000.0f, 0.8f, 0.8f);
        }
        return COLORS[index];
    }

    private void drawMovementKeys(int x, int y, int textColor) {
        for (Key key : this.movementKeys) {
            key.renderKey(x, y, textColor);
        }
    }

    private void drawMouseButtons(int x, int y, int textColor) {
        for (MouseButton button : this.mouseButtons) {
            button.renderMouseButton(x, y, textColor);
        }
    }

    private void drawNewSpace(int x, int y, int textColor) {
        for (NewSpace space : this.newSpaces) {
            space.renderNewSPace(x, y, textColor);
        }
    }

    public static class NewSpace {
        private final KeyBinding space;
        private final int xOffset;
        private final int yOffset;
        private boolean wasPressed = true;
        private long lastPress = 0L;
        private int color = 255;
        private double textBrightness = 1.0;

        public NewSpace(KeyBinding space, int xOffset, int yOffset) {
            this.space = space;
            this.xOffset = xOffset;
            this.yOffset = yOffset;
        }

        public void renderNewSPace(int x, int y, int textColor) {
            boolean pressed = this.space.isKeyDown();
            String name = Keyboard.getKeyName((int)this.space.getKeyCode());
            if (pressed != this.wasPressed) {
                this.wasPressed = pressed;
                this.lastPress = System.currentTimeMillis();
            }
            if (pressed) {
                this.color = Math.min(255, (int)(2L * (System.currentTimeMillis() - this.lastPress)));
                this.textBrightness = Math.max(0.0, 1.0 - (double)(System.currentTimeMillis() - this.lastPress) / 20.0);
            } else {
                this.color = Math.max(0, 255 - (int)(2L * (System.currentTimeMillis() - this.lastPress)));
                this.textBrightness = Math.min(1.0, (double)(System.currentTimeMillis() - this.lastPress) / 20.0);
            }
            Gui.drawRect((int)(x + this.xOffset), (int)(y + this.yOffset), (int)(x + this.xOffset + 70), (int)(y + this.yOffset + 22), (int)(-16777216 + (this.color << 16) + (this.color << 8) + this.color));
            int red = textColor >> 16 & 0xFF;
            int green = textColor >> 8 & 0xFF;
            int blue = textColor & 0xFF;
            FontManager.F18.drawString(name, x + this.xOffset + 17, y + this.yOffset + 8, -16777216 + ((int)((double)red * this.textBrightness) << 16) + ((int)((double)green * this.textBrightness) << 8) + (int)((double)blue * this.textBrightness));
        }
    }

    public static class MouseButton {
        private static final String[] BUTTONS = new String[]{"LMB", "RMB"};
        private final int button;
        private final int xOffset;
        private final int yOffset;
        private final List<Long> clicks = new ArrayList<Long>();
        private boolean wasPressed = true;
        private long lastPress = 0L;
        private int color = 255;
        private double textBrightness = 1.0;

        public MouseButton(int button, int xOffset, int yOffset) {
            this.button = button;
            this.xOffset = xOffset;
            this.yOffset = yOffset;
        }


        public void renderMouseButton(int x, int y, int textColor) {

            boolean pressed = Mouse.isButtonDown((int)this.button);
            String name = BUTTONS[this.button];
            if (pressed != this.wasPressed) {
                this.wasPressed = pressed;
                this.lastPress = System.currentTimeMillis();
                if (pressed) {
                    this.clicks.add(this.lastPress);
                }
            }
            if (pressed) {
                this.color = Math.min(255, (int)(2L * (System.currentTimeMillis() - this.lastPress)));
                this.textBrightness = Math.max(0.0, 1.0 - (double)(System.currentTimeMillis() - this.lastPress) / 20.0);
            } else {
                this.color = Math.max(0, 255 - (int)(2L * (System.currentTimeMillis() - this.lastPress)));
                this.textBrightness = Math.min(1.0, (double)(System.currentTimeMillis() - this.lastPress) / 20.0);
            }
            Gui.drawRect((int)(x + this.xOffset), (int)(y + this.yOffset), (int)(x + this.xOffset + 34), (int)(y + this.yOffset + 22), (int)(-16777216 + (this.color << 16) + (this.color << 8) + this.color));
            int red = textColor >> 16 & 0xFF;
            int green = textColor >> 8 & 0xFF;
            int blue = textColor & 0xFF;
            FontManager.F18.drawString(name, x + this.xOffset + 7, y + this.yOffset + 7, -16777216 + ((int)((double)red * this.textBrightness) << 16) + ((int)((double)green * this.textBrightness) << 8) + (int)((double)blue * this.textBrightness));
            GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
            GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
        }
    }

    public static class Key {
        private final KeyBinding key;
        private final int xOffset;
        private final int yOffset;
        private boolean wasPressed = true;
        private long lastPress = 0L;
        private int color = 255;
        private double textBrightness = 1.0;

        public Key(KeyBinding key, int xOffset, int yOffset) {
            this.key = key;
            this.xOffset = xOffset;
            this.yOffset = yOffset;
        }

        public void renderKey(int x, int y, int textColor) {
            int moduleWidth;
            int x1 = 0;
            int y1 = 0;
            int y2 = 0;
            int width = new ScaledResolution(mc).getScaledWidth();
            if (ClickGui.screen != null) {
                for (CategorysPanels categorysPanels : ClickGUI.categorysPanels) {
                    if (!categorysPanels.category.name().equalsIgnoreCase("Keystrokes")) continue;
                    y2 = categorysPanels.getY();
                    if (categorysPanels.getX() > width / 2) {

                        y1 = categorysPanels.getY() + y + 18;
                        continue;
                    }
                    x1 = categorysPanels.getX();
                    y1 = categorysPanels.getY() + y + 18;
                    if (categorysPanels.getX() > width / 2) {
                        y1 = categorysPanels.getY() + y + 18;
                        continue;
                    }
                    x1 = categorysPanels.getX();
                    y1 = categorysPanels.getY() + y + 18;
                }
            }

            boolean pressed = this.key.isKeyDown();
            String name = Keyboard.getKeyName((int)this.key.getKeyCode());
            if (pressed != this.wasPressed) {
                this.wasPressed = pressed;
                this.lastPress = System.currentTimeMillis();
            }
            if (pressed) {
                this.color = Math.min(255, (int)(2L * (System.currentTimeMillis() - this.lastPress)));
                this.textBrightness = Math.max(0.0, 1.0 - (double)(System.currentTimeMillis() - this.lastPress) / 20.0);
            } else {
                this.color = Math.max(0, 255 - (int)(2L * (System.currentTimeMillis() - this.lastPress)));
                this.textBrightness = Math.min(1.0, (double)(System.currentTimeMillis() - this.lastPress) / 20.0);
            }
            Gui.drawRect((int)(x + this.xOffset), (int)(y + this.yOffset), (int)(x + this.xOffset + 22), (int)(y + this.yOffset + 22), (int)(-16777216 + (this.color << 16) + (this.color << 8) + this.color));
            int red = textColor >> 16 & 0xFF;
            int green = textColor >> 8 & 0xFF;
            int blue = textColor & 0xFF;
            FontManager.F18.drawString(name, x + this.xOffset + 8, y + this.yOffset + 8, -16777216 + ((int)((double)red * this.textBrightness) << 16) + ((int)((double)green * this.textBrightness) << 8) + (int)((double)blue * this.textBrightness));
        }
    }
}
