package zen.relife.Config;

import zen.relife.Relife;
import zen.relife.module.AbstractModule;
import zen.relife.util.Tools;

public class ModuleConfig {
    private static ConfigManager configManager = new ConfigManager(Tools.getConfigPath(), "6.txt");

    public static void loadModules() {
        try {
            for (String s : configManager.read()) {
                for (AbstractModule module : Relife.INSTANCE.getModuleManager().getModules()) {
                    String name = s.split(":")[0];
                    boolean toggled = Boolean.parseBoolean(s.split(":")[1]);
                    if (!module.getName().equalsIgnoreCase(name) || module.getName() == "ClickGui") continue;
                    module.setState(toggled);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void saveModules() {
        try {
            configManager.clear();
            for (AbstractModule module : Relife.INSTANCE.getModuleManager().getModules()) {
                if (module.getName() == "ClickGUI") continue;
                String line = module.getName() + ":" + String.valueOf(module.getState());
                configManager.write(line);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

