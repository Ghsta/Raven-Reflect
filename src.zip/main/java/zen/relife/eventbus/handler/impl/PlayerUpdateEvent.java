package zen.relife.eventbus.handler.impl;

import zen.relife.eventbus.Event;

public final class PlayerUpdateEvent implements Event {
}
