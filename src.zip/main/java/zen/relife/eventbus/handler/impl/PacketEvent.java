package zen.relife.eventbus.handler.impl;

import net.minecraft.network.Packet;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import zen.relife.eventbus.handler.IPacket;

public class PacketEvent extends CancellableEvent {

    private final IPacket packet;

    public PacketEvent(IPacket packet) {
        this.packet = packet;
    }

    public final IPacket getPacket() {
        return this.packet;
    }

}

