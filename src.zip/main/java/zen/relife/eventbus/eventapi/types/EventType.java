package zen.relife.eventbus.eventapi.types;

public enum EventType
{
    PRE, 
    ON, 
    POST, 
    SEND, 
    RECIEVE;
}
