package zen.relife.eventbus.eventapi.events;

public interface Typed
{
    byte getType();
}
