package zen.relife.manager.impl;


import zen.relife.Relife;
import zen.relife.eventbus.handler.impl.EventPacket;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.module.impl.combat.*;
import zen.relife.module.impl.configs.LoadConfig;
import zen.relife.module.impl.configs.SaveConfig;
import zen.relife.module.impl.explolt.Disabler;
import zen.relife.module.impl.explolt.Jump;
import zen.relife.module.impl.misc.*;
import zen.relife.module.impl.movement.*;
import zen.relife.module.impl.movement.InvMove;
import zen.relife.module.impl.render.*;
import zen.relife.module.impl.world.*;
import zen.relife.setting.ModeSetting;
import zen.relife.setting.Setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ModuleManager {
    static ArrayList<AbstractModule> list = new ArrayList();

    public ArrayList<AbstractModule> getModules() {
        return list;
    }
    public static CopyOnWriteArrayList<AbstractModule> modules = new CopyOnWriteArrayList<AbstractModule>();
    public static void onPacketEvent(EventPacket event) {
        for (AbstractModule module : Relife.INSTANCE.getModuleManager().getModules()) {
            module.onPacketEvent(event);
        }
    }

    public final List<String> getSettingByModule(String name) {
        ArrayList setting = new ArrayList();
        for (AbstractModule it :Relife.INSTANCE.getModuleManager().getModules()) {
            Iterator<Setting> iterator;
            if (!it.getName().equalsIgnoreCase(name) || !(iterator = it.getSetting().iterator()).hasNext()) continue;
            Setting s = iterator.next();
            return ((ModeSetting)s).getModes();
        }
        return null;
    }

    public void regMods(AbstractModule ... mods) {
        Collections.addAll(this.getModules(), mods);
    }

    public final List<AbstractModule> getModulesForCategory(ModuleCategory category) {
        ArrayList<AbstractModule> localModules = new ArrayList<AbstractModule>();
        ArrayList<AbstractModule> modules = list;
        int modulesSize = modules.size();
        for (int i = 0; i < modulesSize; ++i) {
            AbstractModule module = modules.get(i);
            if (module.getCategory() != category) continue;
            localModules.add(module);
        }
        return localModules;
    }

    public AbstractModule getModule(String name) {
        for (AbstractModule m : list) {
            if (!m.getName().equalsIgnoreCase(name)) continue;
            return m;
        }
        return null;
    }

    static {
        list.add(new Animations());
        list.add(new Sprint());
        list.add(new FullBright());
        list.add(new ClickGui());
        list.add(new Hud());
        list.add(new ESP());
        list.add(new LoadConfig());
        list.add(new SaveConfig());
        list.add(new AutoClicker());
        list.add(new Reach());
        list.add(new Teams());
        list.add(new KillAura());
        list.add(new HitBox());
        list.add(new SuperKnockBack());
        list.add(new AimAssist());
        list.add(new KeepSprint());
        list.add(new WTAP());
        list.add(new HighJump());
        list.add(new AntiAFK());
        list.add(new Chams());
        list.add(new ChestESP());
        list.add(new ItemESP());
        list.add(new NameTags());
        list.add(new TargetHUD());
        list.add(new FakePlayer());
        list.add(new AntiBot());
        list.add(new Tracers());
        list.add(new AutoTool());
        list.add(new AutoArmor());
        list.add(new AttackEffect());
        list.add(new AttackTrace());
        list.add(new BlockReach());
        list.add(new Eagle());
        list.add(new AntiFire());
        list.add(new AutoRespawn());
        list.add(new Disabler());
        list.add(new Jump());
        list.add(new PlayerEntity());
        list.add(new Trails());
        list.add(new ViewModel());
        list.add(new FastBow());
        list.add(new Xray());
        list.add(new FastLadder());
        list.add(new FastBreak());
        list.add(new EnemyInfo());
        list.add(new Fly());
        list.add(new InvMove());
        list.add(new KillMessage());
        list.add(new AutoDestroy());
        list.add(new ChatRemind());
        list.add(new Velocity());
        list.add(new Speed());
        list.add(new MurderMystery());
        list.add(new AutoL());
        list.add(new DragScreen());
        list.add(new Panic());
    }
    public static void keyPress(int key) {
        for (AbstractModule m : modules) {
            if (m.getKey() == key) {
                m.toggle();
            }
        }
    }
}
