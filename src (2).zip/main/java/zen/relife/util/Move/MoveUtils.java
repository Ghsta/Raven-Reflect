package zen.relife.util.Move;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;

public class MoveUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static final List<Double> frictionValues = new ArrayList<Double>();


    public static double defaultSpeed() {
        return MoveUtils.defaultSpeed((EntityLivingBase) MoveUtils.mc.player);
    }

    public static double defaultSpeed(EntityLivingBase entity) {
        return MoveUtils.defaultSpeed(entity, 0.2);
    }

    public static double defaultSpeed(EntityLivingBase entity, double effectBoost) {
        double baseSpeed = 0.2873;
        return baseSpeed;
    }


    public static float getMovementDirection(float forward, float strafing, float yaw) {
        boolean reversed;
        if (forward == 0.0f && strafing == 0.0f) {
            return yaw;
        }
        boolean bl = reversed = forward < 0.0f;
        float strafingYaw = 90.0f * (forward > 0.0f ? 0.5f : (reversed ? -0.5f : 1.0f));
        if (reversed) {
            yaw += 180.0f;
        }
        if (strafing > 0.0f) {
            yaw -= strafingYaw;
        } else {
            if (!(strafing < 0.0f)) return yaw;
            yaw += strafingYaw;
        }
        return yaw;
    }
    double yaw = MoveUtils.getDirection();
    public static double getDirection() {
        float rotationYaw = MoveUtils.mc.player.rotationYaw;
        if (MoveUtils.mc.player.moveForward < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (MoveUtils.mc.player.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (MoveUtils.mc.player.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (MoveUtils.mc.player.moveStrafing > 0.0f) {
            rotationYaw -= 90.0f * forward;
        }
        if (!(MoveUtils.mc.player.moveStrafing < 0.0f)) return Math.toRadians(rotationYaw);
        rotationYaw += 90.0f * forward;
        return Math.toRadians(rotationYaw);
    }
    public static void setMotion(double speed) {
        double yaw = MoveUtils.getDirection();
        double forward = MoveUtils.mc.player.movementInput.moveForward;
        double strafe = MoveUtils.mc.player.movementInput.moveStrafe;
        if (forward == 0.0 && strafe == 0.0) {
            MoveUtils.mc.player.motionX = 0.0;
            MoveUtils.mc.player.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            MoveUtils.mc.player.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            MoveUtils.mc.player.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
        }
    }
    public static double calculateFriction(double moveSpeed, double lastDist, double baseMoveSpeedRef) {
        frictionValues.clear();
        frictionValues.add(lastDist - lastDist / 159.9999985);
        frictionValues.add(lastDist - (moveSpeed - lastDist) / 33.3);
        double materialFriction = MoveUtils.mc.player.isInWater() ? (double) 0.89f : (MoveUtils.mc.player.isInLava() ? (double) 0.535f : (double) 0.98f);
        frictionValues.add(lastDist - baseMoveSpeedRef * (1.0 - materialFriction));
        return Collections.min(frictionValues);
    }
}