package zen.relife.util;

import net.minecraft.client.Minecraft;

public interface IMinecraft {
    Minecraft mc = Minecraft.getMinecraft();
}
