package zen.relife.util;

public enum Direction {
    FORWARDS,
    BACKWARDS
}