package zen.relife.util;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.Relife;

public class FreelookMod {

    public static boolean cameraToggled = false;
    public static float cameraYaw;
    public static float cameraPitch;

    public FreelookMod() {

    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        if (Keyboard.isKeyDown(getKey()) && !cameraToggled) {
            cameraYaw = Relife.INSTANCE.mc.player.rotationYaw + 180;
            cameraPitch = Relife.INSTANCE.mc.player.rotationPitch;
            cameraToggled = true;
            Relife.INSTANCE.mc.gameSettings.thirdPersonView = 1;
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (!Keyboard.isKeyDown(getKey()) && cameraToggled) {
            cameraToggled = false;
            Relife.INSTANCE.mc.gameSettings.thirdPersonView = 0;
        }
    }

    @SubscribeEvent
    public void cameraSetup(EntityViewRenderEvent.CameraSetup e) {
        if (cameraToggled) {
            e.setYaw(cameraYaw);
            e.setPitch(cameraPitch);
        }
    }

    private int getKey() {
        return 0;
    }
}
