package zen.relife.module.impl.movement;

import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.Relife;
import zen.relife.manager.impl.ModuleManager;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.setting.EnableSetting;
import zen.relife.setting.IntegerSetting;
import zen.relife.util.MathUtils;
import zen.relife.util.TimerUtils;

public class Eagle extends AbstractModule {
 IntegerSetting minDelay = new IntegerSetting("Min Delay", 500.0, 0.0, 1500.0, 1);
 IntegerSetting maxDelay = new IntegerSetting("Max Delay", 500.0, 0.0, 1500.0, 1);
 EnableSetting onKey = new EnableSetting("OnSneakKey", true);
 EnableSetting mode = new EnableSetting("Eagle", true);
 EnableSetting debug = new EnableSetting("Debug", false);
    private TimerUtils sneakTimer = new TimerUtils();

    public Eagle() {
        super("Eagle", 0,ModuleCategory.MOVEMENT,false);
        this.getSetting().add(mode);
        this.getSetting().add(this.minDelay);
        this.getSetting().add(this.maxDelay);
        this.getSetting().add(this.onKey );
        this.getSetting().add(this.debug);
    }

    @Override
    public void disable() {
        super.disable();
        KeyBinding.setKeyBindState(Eagle.mc.gameSettings.keyBindSneak.getKeyCode(), false);
    }
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        double max = this.maxDelay.getCurrent();
        double min = this.minDelay.getCurrent();
        if (min >= max) {
            this.maxDelay.setCurrent(min + 1.0);
            min = this.maxDelay.getCurrent();
        }
        if (mode.getEnable()); {
            double delay = MathUtils.randomNumber(max, min);
            int shiftKey = Eagle.mc.gameSettings.keyBindSneak.getKeyCode();
            if (Eagle.mc.currentScreen != null && !(Eagle.mc.currentScreen instanceof GuiChat)) {
                return;
            }
            if (Eagle.mc.player != null && Eagle.mc.world != null) {
                if (this.onKey.getEnable() && !Keyboard.isKeyDown(shiftKey)) {
                    KeyBinding.setKeyBindState(shiftKey, false);
                } else if (Eagle.mc.world.getBlockState(new BlockPos(Eagle.mc.player).add(0, -1, 0)).getBlock() == Blocks.AIR && Eagle.mc.player.onGround) {
                    KeyBinding.setKeyBindState(shiftKey, true);
                    if (this.debug.getEnable()) {
                        Relife.INSTANCE.instance.sendMessage(String.valueOf(delay));
                    }
                    this.sneakTimer.reset();
                } else if (this.sneakTimer.hasReached((float) delay)) {
                    KeyBinding.setKeyBindState(shiftKey, Keyboard.isKeyDown(shiftKey));
                } else {
                    KeyBinding.setKeyBindState(shiftKey, false);
                }
            } else {
                KeyBinding.setKeyBindState(shiftKey, false);
            }
        }
    }
}
