package zen.relife.module.impl.movement;


import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.util.Tools;

public class KeepSprint
extends AbstractModule {
    public KeepSprint() {
        super("KeepSprint", 0, ModuleCategory.MOVEMENT, false);
    }
    @SubscribeEvent
    public void onUpdate(TickEvent.ClientTickEvent event) {
        if (!Tools.currentScreenMinecraft()) {
            return;
        }
        if (!KeepSprint.mc.player.isSprinting()) {
            KeepSprint.mc.player.setSprinting(true);
        }
    }
}

