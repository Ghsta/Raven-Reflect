package zen.relife.module.impl.world;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.setting.EnableSetting;
import zen.relife.util.Tools;

public class AutoJump
extends AbstractModule {
    private boolean c = false;
    private EnableSetting b = new EnableSetting("Shifting cancel", true);

    public AutoJump() {
        super("AutoJump", 0, ModuleCategory.WORLD, false);
        this.getSetting().add(this.b);
    }

    @Override
    public void disable() {
        super.disable();
        this.c = false;
        this.ju(false);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent ev) {
        if (Tools.isPlayerInGame()) {
            if (!(!AutoJump.mc.player.onGround || this.b.getEnable() && AutoJump.mc.player.isSneaking())) {
                if (AutoJump.mc.world.getCollisionBoxes(AutoJump.mc.player, AutoJump.mc.player.getEntityBoundingBox().offset(AutoJump.mc.player.motionX / 3.0, -1.0, AutoJump.mc.player.motionZ / 3.0)).isEmpty()) {
                    this.c = true;
                    this.ju(true);
                } else if (this.c) {
                    this.c = false;
                    this.ju(false);
                }
            } else if (this.c) {
                this.c = false;
                this.ju(false);
            }
        }
    }

    private void ju(boolean ju) {
        KeyBinding.setKeyBindState(AutoJump.mc.gameSettings.keyBindJump.getKeyCode(), ju);
    }
}

