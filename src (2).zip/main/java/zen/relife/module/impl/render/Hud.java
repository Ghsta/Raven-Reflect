package zen.relife.module.impl.render;

import akka.dispatch.sysmsg.LatestFirstSystemMessageList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.Relife;
import zen.relife.hud.HUDConfigScreen;
import zen.relife.manager.impl.FontManager;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.module.impl.render.util.ColorUtil;
import zen.relife.module.impl.render.util.RoundedUtil;
import zen.relife.setting.EnableSetting;
import zen.relife.setting.ModeSetting;
import zen.relife.util.*;
import zen.relife.utils.ClientUtil;
import zen.relife.utils.ColorUtils;
import zen.relife.utils.CustomFont;
import zen.relife.utils.FontManagersssssssss;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import static zen.relife.utils.Utils.neverloseFont;
import static zen.relife.utils.Utils.tenacityFont18;

public class Hud extends AbstractModule {
    public static EnableSetting notification = new EnableSetting("Notification", true);
    private ModeSetting mode = new ModeSetting("Mode", "Text", Arrays.asList("Text", "Rainbow"), this);
    private EnableSetting WaterMark = new EnableSetting("WaterMark", true);
    private int width;

    public static FontManagersssssssss font;
    public SimpleDateFormat formatter;

    //HudMods
    private EnableSetting Health = new EnableSetting("Health", false);
    public static EnableSetting SprintRender = new EnableSetting("SprintRender", false);
    public static EnableSetting InventoryHUD = new EnableSetting("InventoryHUD", false);

    public static EnableSetting ArrayList = new EnableSetting("ArrayList", false);
    public static EnableSetting TargetHUD = new EnableSetting("TargetHUD", false);
    public static EnableSetting Keystrokes = new EnableSetting("Keystrokes", false);

    public Hud() {
        super("HUD", Keyboard.KEY_H, ModuleCategory.RENDER, true);
        this.getSetting().add(this.mode);
        this.getSetting().add(this.Health);
        this.getSetting().add(this.WaterMark);
        this.getSetting().add(notification);
        this.getSetting().add(SprintRender);
        this.getSetting().add(InventoryHUD);
        this.getSetting().add(ArrayList);
        this.getSetting().add(TargetHUD);
        this.getSetting().add(Keystrokes);
    }

    @SubscribeEvent
    public void Notification(RenderGameOverlayEvent.Text event) {
        if (!notification.getEnable()) {
            return;
        }
        Relife.INSTANCE.notificationManager.draw();
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        ScaledResolution s = new ScaledResolution(mc);
        int width = new ScaledResolution(mc).getScaledWidth();
        int height = new ScaledResolution(mc).getScaledHeight();
        int y = 1;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof GuiMainMenu)) return;
        if (this.mode.getCurrent().equalsIgnoreCase("Text")) {




        } else if (this.mode.getCurrent().equalsIgnoreCase("Rainbow")) {

 FontManager.C16.drawStringWithShadow(" | " + Relife.cName + " | " + (mc.isSingleplayer() ? "localhost:25565" : !mc.getCurrentServerData().serverIP.contains(":") ? mc.getCurrentServerData().serverIP + ":25565" : mc.getCurrentServerData().serverIP) + " | " + Minecraft.getDebugFPS() + "fps", 7, 9, ColorUtils.rainbow(2));
        }

        ArrayList<AbstractModule> enabledModules = new ArrayList<AbstractModule>();
        for (AbstractModule m : Relife.INSTANCE.getModuleManager().getModules()) {
            if (!m.state) continue;
            enabledModules.add(m);
        }

        int i = 0;
        if(this.Health.getEnable()){
            if (mc.player.getHealth() >= 0.0f && mc.player.getHealth() < 10.0f) {
                this.width = 3;
            }
            if (mc.player.getHealth() >= 10.0f && mc.player.getHealth() < 100.0f) {
                this.width = 5;
            }
            mc.fontRenderer.drawStringWithShadow("♥" + MathHelper.sqrt(mc.player.getHealth()), (float) (new ScaledResolution(mc).getScaledWidth() / 2 - this.width), (float) (new ScaledResolution(mc).getScaledHeight() / 2 - 15), -1);  }

        if (!(mc.currentScreen instanceof HUDConfigScreen)) {
            Relife.INSTANCE.hudManager.renderMods();
        }
    }
}
