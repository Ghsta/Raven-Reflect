package zen.relife.module.impl.render;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.util.RenderUtils;

public class PlayerEntity extends AbstractModule {
    public PlayerEntity() {
        super("PlayerEntity", Keyboard.KEY_NONE, ModuleCategory.RENDER,false);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post event) {
        switch (event.getType()) {
            case TEXT:
                RenderUtils.renderEntity(mc.player, 30, 40, 100);
                break;
            default:
                break;
        }
    }
}
