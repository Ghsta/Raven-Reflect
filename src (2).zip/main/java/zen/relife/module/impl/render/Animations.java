package zen.relife.module.impl.render;


import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import zen.relife.eventbus.handler.impl.Render2DEvent;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.module.impl.render.Render.IItemRenderer;
import zen.relife.setting.EnableSetting;
import zen.relife.setting.IntegerSetting;

public class Animations extends AbstractModule {

    private static Animations INSTANCE = new Animations();
    public EnableSetting ed = new EnableSetting("EquipDisable", Boolean.valueOf(true));
    public EnableSetting auraOnly =new EnableSetting("auraOnly", Boolean.valueOf(false));
    public IntegerSetting fapSmooth =new IntegerSetting("fapSmooth", 4.0, 0.5, 15,1);
    public IntegerSetting slowValue = new IntegerSetting("SlowValue", 6, 1, 50,1);
    public float shitfix = 1;
    public boolean abobka228 = false;


    public Animations() {
        super("Animations", 0, ModuleCategory.RENDER,false);
        this.setInstance();
        this.getSetting().add(this.ed);
        this.getSetting().add(this.auraOnly);
        this.getSetting().add(this.fapSmooth);
        this.getSetting().add(this.slowValue);
    }

    public static Animations getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Animations();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @SubscribeEvent
    public void onRender2D(Render2DEvent e) {
        if (mc.world != null && mc.player != null) {
            shitfix = mc.player.getSwingProgress(mc.getRenderPartialTicks());
        }
    }

    public void onUpdate() {
        abobka228 = ((IItemRenderer)mc.getItemRenderer()).getEquippedProgressMainHand() < 1f;
        if (ed.getEnable() && ((IItemRenderer)mc.getItemRenderer()).getEquippedProgressMainHand() >= 0.9) {
            ((IItemRenderer)mc.getItemRenderer()).setEquippedProgressMainHand(1f);
            ((IItemRenderer)mc.getItemRenderer()).setItemStackMainHand(Animations.mc.player.getHeldItemMainhand());
        }
    }
}