package zen.relife.module.impl.render.Render;

import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.item.ItemStack;


public interface IItemRenderer {

    void setEquippedProgressMainHand(float var1);


    float getEquippedProgressMainHand();


    void setItemStackMainHand(ItemStack var1);
}
