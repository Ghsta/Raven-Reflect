package zen.relife.module.impl.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import zen.relife.Relife;
import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.util.ChatUtils;

import java.util.Objects;

public class AntiBot extends AbstractModule {
    public AntiBot() {
        super("AntiBot", Keyboard.KEY_NONE, ModuleCategory.RENDER, false);
    }

    @SubscribeEvent
    public void onUpdate(RenderWorldLastEvent e) {
        try {
            for (EntityPlayer entityPlayer : mc.world.playerEntities) {
                if (entityPlayer.isPlayerSleeping() && entityPlayer != mc.player) {
                    mc.world.removeEntity(entityPlayer);
                }
            }
        } catch (Exception ex) {
            ChatUtils.message("AntiBot ERROR!");
        }
    }

}