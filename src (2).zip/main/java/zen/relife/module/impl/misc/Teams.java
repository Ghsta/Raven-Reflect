package zen.relife.module.impl.misc;

import zen.relife.module.AbstractModule;
import zen.relife.module.ModuleCategory;
import zen.relife.setting.ModeSetting;

import java.util.Arrays;

public class Teams
extends AbstractModule {
    public ModeSetting mode = new ModeSetting("Mode", "ArmorColor", Arrays.asList("Base", "ArmorColor", "NameColor", "TabList"), this);

    public Teams() {
        super("Teams", 0, ModuleCategory.MISC, false);
        this.getSetting().add(this.mode);
    }
}

