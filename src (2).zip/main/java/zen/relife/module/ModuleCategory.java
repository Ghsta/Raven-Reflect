package zen.relife.module;

public enum ModuleCategory {

    COMBAT("Combat"),
    MOVEMENT("Movement"),

    RENDER("Render"),
    WORLD("World"),
    MISC("Misc"), TEXTGUI("textgui"), CONFIG("Config"), OTHER("Other"), EXPLOIT("Explolt"), Keystrokes("Keystrokes");




    private final String name;

    ModuleCategory(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
