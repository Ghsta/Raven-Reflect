package zen.relife.render.font;

import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public abstract class FontLoaders {
    public static EnglishFontRenderer arial18;

    static {
        FontLoaders.arial18 = new EnglishFontRenderer(getArial(18), true, true);
    }

    private static Font getArial(final int size) {
        Font font;
        try {
            final File file = new File("C:\\Users\\Administrator\\Desktop\\y\\Relife.ttf");
            final InputStream is = new FileInputStream(file);
            font = Font.createFont(0, is);
            font = font.deriveFont(0, (float) size);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }
}
