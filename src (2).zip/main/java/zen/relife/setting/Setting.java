package zen.relife.setting;


import zen.relife.module.AbstractModule;

public class Setting {
    public final String name;
    private AbstractModule parent;

    public Setting(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public AbstractModule getParentMod() {
        return this.parent;
    }
}

