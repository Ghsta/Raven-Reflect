package zen.relife.eventbus;

public interface Event {
}

