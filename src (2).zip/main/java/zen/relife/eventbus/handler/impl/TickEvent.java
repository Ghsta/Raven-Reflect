package zen.relife.eventbus.handler.impl;


import zen.relife.eventbus.Event;

public class TickEvent implements Event {
    public class ClientTickEvent {
    }
}
