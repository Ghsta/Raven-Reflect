package zen.relife;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.server.SPacketEntityTeleport;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import zen.relife.Notifications.NotificationManager;
import zen.relife.eventbus.EventBus;
import zen.relife.eventbus.handler.IHandler;
import zen.relife.eventbus.handler.Listener;
import zen.relife.eventbus.handler.SubscribeEvent;
import zen.relife.eventbus.handler.impl.PlayerKeyEvent;
import zen.relife.manager.impl.EventManager;
import zen.relife.manager.impl.HudManager;
import zen.relife.manager.impl.ModuleManager;
import zen.relife.module.AbstractModule;
import zen.relife.ui.ClickGUI.ClickGUI;
import zen.relife.util.*;

import java.io.IOException;
import java.lang.reflect.Field;
import java.security.NoSuchAlgorithmException;

import static net.minecraftforge.common.MinecraftForge.EVENT_BUS;

@Mod(modid = Relife.MODID, name = Relife.NAME, version = Relife.VERSION)
public final class Relife {

    public static boolean isObfuscate;
    public static final String MODID = "relife";
    public static final String NAME = "Relife b1";
    public static final String VERSION = "1.0";
    public static final String REVISION = "@REVISION@";
    public static String cName = "Relife Client";

    public Minecraft mc = Minecraft.getMinecraft();
    public CpsHelper cpsHelper;

    public static final Relife INSTANCE = new Relife();

    public static EventEngine eventEngine;
    private final EventBus eventBus = new EventBus();


    @Mod.Instance
    public  Relife instance;
    public  String prefix;
    public boolean inited;
    private ModuleManager moduleManager;
    public NotificationManager notificationManager;
    public HudManager hudManager;
    public ClickGUI clickGUI;
    public Animate animate;
    public FontHelper fontHelper;

    public Relife() {
        this.prefix = "§f[" + ChatFormatting.RED + "K§f]";
    }
    public static boolean nullCheck() {
        final Minecraft mc = Minecraft.getMinecraft();
        return mc.player == null || mc.world == null;

    }

    @Mod.EventHandler
    public void PreInit(FMLPreInitializationEvent event) {(Relife.INSTANCE.instance = new Relife()).init();}


    @Mod.EventHandler
    public void init() {
        Relife.INSTANCE.initialize();
    }

    public void initialize() {
        try {
            new VerifyUtil();
        }
        catch (IOException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        System.out.println("Initializing Relife client (" + REVISION + ")");
        EVENT_BUS.register(this);
        moduleManager = new ModuleManager();
        hudManager  = new HudManager();
        clickGUI = new ClickGUI();
        eventEngine = new EventEngine();
        eventBus.register(new EventListener());
        notificationManager = new NotificationManager();
        animate = new Animate();
        fontHelper = new FontHelper();
        EVENT_BUS.register(new ForgeEventListener());
    }
    public void setOBF() {
        instance = this;
        try {
            Field F = SPacketEntityTeleport.class.getDeclaredField("field_149456_b");
            isObfuscate = true;
        }
        catch (NoSuchFieldException ex) {
            try {
                Field F = SPacketEntityTeleport.class.getDeclaredField("posX");
                isObfuscate = false;
            }
            catch (NoSuchFieldException e) {
                e.printStackTrace();
            }
        }
    }
    public EventBus getEventBus() {
        return eventBus;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public void error(String syntaxError) {

    }

    private final static class EventListener implements IHandler {
        @SubscribeEvent
        public final Listener<PlayerKeyEvent> playerKeyEventListener =
                event -> Relife.INSTANCE.getModuleManager().getModules()
                        .stream()
                        .filter(module -> module.getKey() == event.getKey())
                        .forEach(AbstractModule::toggle);
    }


    public void sendMessage(String message) {
        message = Relife.INSTANCE.instance.prefix + message;

    }
}

